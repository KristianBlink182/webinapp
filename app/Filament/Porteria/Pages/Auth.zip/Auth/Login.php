<?php

namespace App\Filament\Porteria\Pages\Auth;

use Filament\Pages\Auth\Login as BaseLogin;

class Login extends BaseLogin
{
    protected static string $view = 'filament.porteria.pages.auth.login';

    public function getLayout(): string
    {
        return 'filament-panels::components.layout.base';
    }
}